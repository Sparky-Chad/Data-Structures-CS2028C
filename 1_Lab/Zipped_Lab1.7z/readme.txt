Source and executable files were created within ubuntu using mingw.

This may or may not be supported but should work as an executable, otherwise compile using mingw_g++ or the linux windows subsystem, or import the files from source into VS

The code may be viewed within your choice of ide or by using notepad
