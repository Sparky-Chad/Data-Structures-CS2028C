Files written and coded by Chad and Colton

To use, use the executable in the root folder, or import lab2 directory into visual studio as it is in the visual studio format. Otherwise one can use mingw g++ as g++ Player.cpp Source.cpp

Colton had worked mostly on the Player class with some work on shot by chad while Chad worked on the main structure of Source.cpp with work done by Colton on the Pass and Score Function.
